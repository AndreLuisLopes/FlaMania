import React, { useEffect, useState } from 'react';
import {
  View, Text, ScrollView, StyleSheet, Image, ActivityIndicator,
} from 'react-native';
import axios from 'axios';

export default function HomeScreen() {
  const [partidaDestaque, setPartidaDestaque] = useState(null);
  const [proximas, setProximas] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchDados = async () => {
    try {
      const res = await axios.get(
        'https://api.api-futebol.com.br/v1/times/18/partidas',
        {
          headers: {
            Authorization: 'Bearer live_6ee68252f8bed19b62bffb712cf774',
          },
        }
      );

      const { ultimas, proximas: proximasPartidas } = res.data;

      const emAndamento = ultimas.find(p => p.status === 'em_andamento');
      const ultima = ultimas[0];
      const destaque = emAndamento || ultima;

      setPartidaDestaque(destaque);
      setProximas(proximasPartidas.slice(0, 2));
    } catch (e) {
      console.error('Erro ao buscar partidas:', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDados();
  }, []);

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Olá André,</Text>
        <Text style={styles.subtitle}>Bem vindo ao FlaMania</Text>
      </View>

      <Text style={styles.section}>Torneios</Text>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.torneiosScroll}>
        {['libertadores.png', 'brasileirao.png', 'carioca.png'].map((img, index) => (
          <Image key={index} source={{ uri: `https://meusite.com/assets/${img}` }} style={styles.torneioIcon} />
        ))}
      </ScrollView>

      <View style={styles.destaqueContainer}>
        <Text style={styles.section}>Partida em Destaque</Text>
        {loading ? (
          <ActivityIndicator size="large" color="#d00" />
        ) : partidaDestaque ? (
          <View style={styles.matchCard}>
            <Text style={styles.matchScore}>
              {partidaDestaque.placar_mandante} - {partidaDestaque.placar_visitante}
            </Text>
            <Text style={styles.matchTeams}>
              {partidaDestaque.time_mandante.nome} vs {partidaDestaque.time_visitante.nome}
            </Text>
            <Text style={styles.matchInfo}>
              {partidaDestaque.campeonato?.nome}
            </Text>
          </View>
        ) : (
          <Text style={{ color: '#888' }}>Nenhuma partida disponível</Text>
        )}
      </View>

      <View>
        <Text style={styles.section}>Próximos Jogos</Text>
        {proximas.map((jogo, idx) => (
          <View key={idx} style={styles.nextMatch}>
            <Text style={styles.nextMatchText}>
              {jogo.time_mandante.nome} VS {jogo.time_visitante.nome}
            </Text>
            <Text style={styles.nextMatchDate}>
              {new Date(jogo.data_realizacao_iso).toLocaleString('pt-BR')}
            </Text>
          </View>
        ))}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff', paddingHorizontal: 16 },
  header: { marginVertical: 20 },
  title: { fontSize: 22, fontWeight: 'bold' },
  subtitle: { fontSize: 14, color: '#888' },
  section: { fontSize: 18, fontWeight: 'bold', marginVertical: 10, color: '#d00' },

  torneiosScroll: { marginBottom: 20 },
  torneioIcon: { width: 50, height: 50, marginRight: 12, borderRadius: 25 },

  destaqueContainer: { marginBottom: 20 },
  matchCard: {
    backgroundColor: '#f0f0f0', borderRadius: 12, padding: 16, alignItems: 'center',
  },
  matchScore: { fontSize: 26, fontWeight: 'bold' },
  matchTeams: { fontSize: 16, fontWeight: '600' },
  matchInfo: { fontSize: 12, color: '#777' },

  nextMatch: {
    backgroundColor: '#222', padding: 12, borderRadius: 10, marginVertical: 6,
  },
  nextMatchText: { color: '#fff', fontSize: 14 },
  nextMatchDate: { color: '#aaa', fontSize: 12 },
});
